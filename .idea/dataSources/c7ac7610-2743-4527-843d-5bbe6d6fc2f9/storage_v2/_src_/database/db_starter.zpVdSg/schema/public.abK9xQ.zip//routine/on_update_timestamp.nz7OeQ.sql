create function on_update_timestamp() returns trigger
    language plpgsql
as
$$
  BEGIN
    NEW.updated_at = now();
    RETURN NEW;
  END;
$$;

alter function on_update_timestamp() owner to postgres;

